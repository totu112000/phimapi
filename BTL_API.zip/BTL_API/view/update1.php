<html>
    <head>
        <title>Trang sửa thông tin sản phẩm</title>
        <style>
            a:hover{
                color: red;
            }
        </style>
    </head>
    <body>

<?php
   $con = mysqli_connect("localhost","root","","webphimapi");
   if(mysqli_connect_error($con)){
       echo "Không thể kết nối đến CSDL :".mysqli_connect_error($con);   
   }else{
       //echo "Kết nối thành công!";
   }

    
    if( isset($_GET['idMovie'])){$idMovie = $_GET['idMovie'];
    }else{$idMovie = "";}
    $where = "WHERE idMovie = '$idMovie'";
    $sql= "SELECT * FROM movie $where ";
    //SQL update
    
    

    if(isset($_GET['movieName']) && isset($_GET['authorName'])  && isset($_GET['IMDB']) && isset($_GET['movieLink']) && isset($_GET['introduce']) && isset($_GET['date']) && isset($_GET['time']) && isset($_GET['avatar']) && isset($_GET['screenshot']) && isset($_GET['idCategory'])){
    $sql_update =" UPDATE movie SET movieName = '{$_GET['movieName']}', authorName ='{$_GET['authorName']}', IMDB='{$_GET['IMDB']}', introduce='{$_GET['introduce']}', date='{$_GET['date']}', time='{$_GET['time']}',avatar='{$_GET['avatar']}',screenshot='{$_GET['screenshot']}', idCategory='{$_GET['idCategory']}'    $where   ";
        //echo $sql_update;
}
        
    //Tiến hành update
    
    if(isset($_GET['movieName']) && isset($_GET['authorName'])  && isset($_GET['IMDB']) && isset($_GET['movieLink']) && isset($_GET['introduce']) && isset($_GET['date']) && isset($_GET['time']) && isset($_GET['avatar']) && isset($_GET['screenshot']) && isset($_GET['idCategory'])){
        if(mysqli_query($con,$sql_update)){
            //echo "Lấy thành công dữ liệu";
        }else{echo "Có lỗi xảy ra ".mysqli_error($con);}
        }
    
    if($result = mysqli_query($con,$sql)){
        //echo "Update dữ liệu thành công!";
        
    }else{
        echo " Có lỗi xảy ra !".mysqli_error($con);
    }
    //Sửa 
    while($rows = mysqli_fetch_array($result)){
        echo "<form >
        <input type='hidden' name = 'idMovie' value = '{$rows['idMovie']}'><br>
        movieName : 
        <input type='text' name = 'movieName' value = '{$rows['movieName']}'> <br> 
        authorName : 
        <input type='text' name = 'authorName' value = '{$rows['authorName']}'> <br> 
        IMDB :  
        <input type='text' name = 'IMDB' value = '{$rows['IMDB']}'> <br>
        movieLink :  
        <input type='text' name = 'movieLink' value = '{$rows['movieLink']}'> <br>
        introduce : 
        <input type='text' name = 'introduce' value = '{$rows['introduce']}'> <br> 
        date : 
        <input type='text' name = 'date' value = '{$rows['date']}'><br> 
        time: 
        <input type='text' name = 'time' value = '{$rows['time']}'> <br>  
        avatar: 
        <input type='text' name = 'avatar' value = '{$rows['avatar']}'> <br> 
        screenshot: 
        <input type='text' name = 'screenshot' value = '{$rows['screenshot']}'> <br> 
        idCategory :
        <input type='number' name = 'idCategory' value = '{$rows['idCategory']}'><br>
        <input type='submit' name = 'sua' value ='Sửa'></form> ";
        
    }
//update ảnh 
    if(isset($_POST['update'])){
        if(isset($_FILES['profile']['name'])){
            $anh = '../picture/';
            $temp=$_FILES['profile']['tmp_name'];
            $profile_name=$anh.basename($_FILES['profile']['name']);
            //echo $profile_name;
            if(move_uploaded_file($temp,$profile_name)){
                //echo "file đã được upload";
            }else{
                echo "upload thất bại";
            }
        
        $update = mysqli_query($con,"UPDATE movie set avatar='$profile_name' $where");
        if($update){
            //echo "update dữ liệu thành công!";
        }else{
            echo "Update dữ liệu thất bại!";
        }
        
        }

    }

//:Đóng kết nối
    mysqli_close($con);
    unset($sql,$row,$result);
?>  
     <form action= '' method='POST' enctype='multipart/form-data'>
        Chọn file update: <input type = file name = 'profile'> 
	    <input type = 'submit' value = 'update' name = 'update'>
        </form>
    
    <h3><a href='http://localhost:8888/BTL_API/view/archives.php'>Quay lại kho phim</a></h3>

        

    </body>
</html>