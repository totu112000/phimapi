<?php
        $con = mysqli_connect("localhost","root","","webphimapi");
        if(mysqli_connect_error($con)){
            echo "Không thể kết nối đến CSDL :".mysqli_connect_error($con);   
        }else{
            //echo "Kết nối thành công!";
        }

         //Xóa dữ liệu
        if( isset($_GET["xoa"]) && $_GET["xoa"] == "delete")
        {
        $idMovie = $_GET['idMovie'] ;
        $delete = "delete from movie where idMovie = $idMovie " ;
        if ( mysqli_query($con, $delete))
        {
            echo "Xóa dữ liệu thành công" ;
            header ("Location: archives.php") ;
        }
        else   
            echo "Xóa dữ liệu thất bại" ;
        }
    //Thêm dữ liệu
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {              
                if(isset($_POST["sub"])){
                        if(isset($_POST["ten_phim"]))          
                        $movieName = $_POST["ten_phim"];                   
                        $authorName = $_POST["ten_tac_gia"];
                        $IMDB = $_POST["diemIMDB"];
                        $movieLink = $_POST["link_phim"];
                        $introduce = $_POST["mota"];
                        $date = $_POST["ngayramat"];
                        $time = $_POST["thoiluong"];
                        $idCategory = $_POST["danhmuc"];   

                        $avatar =$_POST["anhdaidien"];   

                        
                        $screenshot = $_POST["anhnen"];   

                        
                                 
                                $sql45 = "insert into movie(movieName,authorName,IMDB,movieLink,introduce,date,time,avatar,screenshot,idCategory) values ('$movieName','$authorName','$IMDB','$movieLink','$introduce','$date','$time','$avatar','$screenshot','$idCategory')";
                                if(mysqli_query($con,$sql45)){
                                echo "Thêm dữ liệu thành công !";
                                header ("Location: archives.php");
                                }else{
                                echo "Thêm dữ liệu thất bại! ";
                            }
                        }
        }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Trang quản lý phim</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
        <style type="text/css">
            table{
                width: 100%;
            }
            tr th{
                border: 1px solid rgb(85, 201, 39);
                color: rgb(247, 8, 8);
            }
            header {
                width: 100%;
                background-color:dodgerblue;
                padding: 10px;
                text-align: center;
                font-size: 25px;
                color: white;
                }
            nav {
                float: left;
                width: 100%;
                height: 200px;
                background-color: aliceblue;
                padding: 20px;
                }
            section::after {
                content: "";
                display: table;
                clear: both;
                }
            a:hover{
                color:red;
            }
        </style>
        <script src='srcipt.js'> </script>
    </head>
    <body>
        <header>
            Kho phim
        </header>
        <section>       
           <h3>Chọn thể loại hiển thị</h3>      
           <?php
            echo "
                <a  href='http://localhost:8888/BTL_API/view/archives.php?'>Tất cả phim</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=1 ."'>Hành động</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=2 ."'>Phiêu lưu</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=3 ."'>Gỉa tưởng</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=4 ."'>Lãng mạn</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=5 ."'>Drama</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=6 ."'>Phép thuật</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=7 ."'>Học đường</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=8 ."'>Âm nhạc</a>
                <a  href='http://localhost:8888/BTL_API/view/archives.php?idCategory=".$row['idCategory']=9 ."'>Siêu nhiên </a>";

            ?>
            
        
        <form>
            Tìm kiếm:
            <input type="text" id="txt1" onkeyup="showHint(this.value);"/>
        </form>
        <?php
        if(isset($_GET['q'])){$q = $_GET['q'];
        }else{$q = "";}
        $where3="WHERE movieName LIKE '%$q%' OR IMDB='$q' ";
        if(isset($_GET['p'])){
            $p = (int) $_GET['p'];
            if($p<1) $p=1;
        }else{
            $p=1;
        }
        $length = 5;
        $start = $length*($p-1);
        $sql2 = "SELECT * FROM movie $where3 ORDER BY movieName DESC ";
        //echo $sql2."<br>";
        $result2 = mysqli_query($con,"SELECT * FROM movie $where3");
        if($result2 = mysqli_query($con,$sql2)){
            //echo " lấy thành công dữ liệu";
        }else{
            echo "Có lỗi xảy ra ".mysqli_error($con);
        }
        $numpage = ceil(mysqli_num_rows($result2)/$length);
        for($i=1;$i<=$numpage;$i++){
            if($i!=$p)
            echo "<a href= 'http://localhost:8888/BTL_API/view/archives.php?p=$i'>$i</a>";
            else echo "<a href= 'http://localhost:8888/BTL_API/view/archives.php?p=$i'> <font color = red size = 4 >$i</font></a>";
        }


    /*    while($row1 = mysqli_fetch_array($result2)){
            echo "
            <span idMovie='txtHint'></span>
            <tr>
                <td>{$row1['idMovie']}</td>
                <td style= 'text-align:center;'>{$row1['movieName']}</td>
                <td>{$row1['authorName']}</td>
                <td>{$row1['IMDB']}</td>
                <td><b>{$row1['movieLink']}</b></td>
                <td>{$row1['introduce']}</td>
                <td><b>{$row1['date']}</b></td>
                <td><b>{$row1['time']}</b></td>
                <td><img style='width:150px;' src='".$row1['avatar']."'></td>
                <td><img style='width:150px;' src='".$row1['screenshot']."'></td>
                <td>{$row1['idCategory']}</td>
                <td><a class='btn btn-danger' href='archives.php?idMovie=".$row1['idMovie']."&xoa=delete' >Xóa</a>
                <a class='btn btn-warning' href='update1.php?idMovie=".$row1['idMovie']."'>Sửa</a></td>
            </tr>";
        } 
             */

        ?>
           

        <div class="nav-right">
            <table align="center" border="1" cellspacing="5" cellpading="10" >              
                <tr>
                <th styele >idMovie</th>  
                    <th>movieName</th>            
                    <th>authorName</th>
                    <th>IMDB</th>
                    <th>movieLink</th>
                    <th>introduce</th>
                    <th>date</th>
                    <th>time</th>
                    <th>avatar</th>
                    <th>screenshot</th>
                    <th>idCategory</th>
                    <th>Hành động</th>
                </tr>
            <?php
            if(isset($_GET['idCategory'])){$idCategory = $_GET['idCategory'];
            }else{$idCategory= "";}
            $where = "WHERE idCategory = '$idCategory'";
            $sql3 = "SELECT * FROM movie $where";
            $result3 = mysqli_query($con,$sql3);
            if( $result3 = mysqli_query($con,$sql3)){
                //echo "Lấy dữ liệu thành công";
            }else{
                echo "Có lỗi xảy ra: ".mysqli_error($con);
            }
            if(isset($_GET['idCategory'])==1){
            if (mysqli_num_rows($result3)>0){
                while($row = mysqli_fetch_array($result3)){
                    echo "
                    <span idMovie='txtHint'></span>
                    <tr>
                        <td>{$row['idMovie']}</td>
                        <td style= 'text-align:center;'>{$row['movieName']}</td>
                        <td>{$row['authorName']}</td>
                        <td>{$row['IMDB']}</td>
                        <td>{$row['movieLink']}</td>
                        <td>{$row['introduce']}</td>
                        <td>{$row['date']}</td>
                        <td>{$row['time']}</td>
                        <td><img style='width:150px;' src='".$row['avatar']."'></td>
                        <td><img style='width:150px;' src='".$row['screenshot']."'></td>
                        <td>{$row['idCategory']}</td>
                        <td><a class='btn btn-danger' href='archives.php?idMovie=".$row['idMovie']."&xoa=delete' >Xóa</a>
                        <a class='btn btn-warning' href='update1.php?idMovie=".$row['idMovie']."'>Sửa</a></td>
                    </tr>";}
            } else {
                echo "Bảng không chứa dữ liệu ";
            }
            }elseif(isset($_GET['idCategory'])==2){
                if (mysqli_num_rows($result3)>0){
                    while($row = mysqli_fetch_array($result3)){
                        echo "
                        <span idMovie='txtHint'></span>
                        <tr>
                                <td>{$row['idMovie']}</td>
                                <td style= 'text-align:center;'>{$row['movieName']}</td>
                                <td>{$row['authorName']}</td>
                                <td>{$row['IMDB']}</td>
                                <td>{$row['movieLink']}</td>
                                <td>{$row['introduce']}</td>
                                <td>{$row['date']}</td>
                                <td>{$row['time']}</td>
                                <td><img style='width:150px;' src='".$row['avatar']."'></td>
                                <td><img style='width:150px;' src='".$row['screenshot']."'></td>
                                <td>{$row['idCategory']}</td>
                                <td><a class='btn btn-danger' href='archives.php?idMovie=".$row['idMovie']."&xoa=delete' >Xóa</a>
                                <a class='btn btn-warning' href='update1.php?idMovie=".$row['idMovie']."'>Sửa</a></td>
                    </tr>";}
                } else {
                    echo "Bảng không chứa dữ liệu ";
                }
            }else{
                    $sql1 = "SELECT * FROM movie LIMIT $start,$length";
                    $result = mysqli_query($con, $sql1);
                    if($result = mysqli_query($con,$sql1)){
                        //echo "Lấy dữ liệu thành công!";
                    }else{
                        echo "Có lỗi xảy ra: ".mysqli_error($con);
                    }
                    if (mysqli_num_rows($result)>0){
                    while($row = mysqli_fetch_array($result)){
                        echo "
                        <span idMovie='txtHint'></span>
                        <tr>
                                <td>{$row['idMovie']}</td>
                                <td style= 'text-align:center;'>{$row['movieName']}</td>
                                <td>{$row['authorName']}</td>
                                <td>{$row['IMDB']}</td>
                                <td>{$row['movieLink']}</td>
                                <td>{$row['introduce']}</td>
                                <td>{$row['date']}</td>
                                <td>{$row['time']}</td>
                                <td><img style='width:150px;' src='".$row['avatar']."'></td>
                                <td><img style='width:150px;' src='".$row['screenshot']."'></td>
                                <td>{$row['idCategory']}</td>
                                <td><a class='btn btn-danger' href='archives.php?idMovie=".$row['idMovie']."&xoa=delete' >Xóa</a>
                                <a class='btn btn-warning' href='update1.php?idMovie=".$row['idMovie']."'>Sửa</a></td>
                    </tr>";}
                } else {
                    echo "Bảng không chứa dữ liệu ";
                }
            }
            
            mysqli_close($con);
        	unset($sql1,$rows,$result);
            ?>
            </table> 
            
        </div>         
        <header style="background-color:red;">Thêm phim</header>
        <form action="archives.php" method="POST" enctype="multipart/form-data">
            <label><br> movieName : </label><input type="text" name="ten_phim">
            <label><br> authorName : </label><input type="text" name="ten_tac_gia">
            <label><br> IMDB : </label><input type="text" name="diemIMDB">
            <label><br> movieLink: </label><input type="text" name="link_phim">
            <label><br> introduce : </label><textarea name="mota" cols="100" rows="10"></textarea>
            <label><br> date : </label><input type="text" name="ngayramat">
            <label><br> time : </label><input type="text" name="thoiluong">
            <label><br> avatar : </label><input type="text" name="anhdaidien">
            <label><br> screenshot : </label><input type="text" name="anhnen">
            <label><br> idCategory : </label><input type="number" name="danhmuc" min="1" max="20">
            <br><input type="submit" class="btn btn-primary" name="sub" value = "Thêm phim">
            <input type="reset" class="btn btn-danger">
        </form>   
        </section>
    </body>
</html>