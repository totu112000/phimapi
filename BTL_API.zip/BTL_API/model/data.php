<?php
class data{
    private $conn;

    //data 
    public $id_phim;
    public $tenphim;
    public $tentacgia;
    public $IMDB;
    public $linkphim;
    public $mota;
    public $ngayramat;
    public $thoiluong;
    public $anhdaidien;
    public $anhcreenshot;
    public $id_danhmuc;

    //connect_db
    public function __construct($db){
        $this->conn = $db;
    }

    //read data
    public function read(){
        $query = "SELECT * FROM phim_tbl ORDER BY id_phim ASC";

        $stmt = $this->conn->prepare($query);

        $stmt->execute();
        return $stmt;
    }

    //show data
    public function show(){
        $query = "SELECT * FROM phim_tbl WHERE id_phim=? limit 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id_phim);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $this->tenphim = $row['tenphim'];
        $this->tentacgia = $row['tentacgia'];
        $this->IMDB = $row['IMDB'];
        $this->linkphim = $row['linkphim'];
        $this->mota = $row['mota'];
        $this->ngayramat = $row['ngayramat'];
        $this->thoiluong = $row['thoiluong'];
        $this->anhdaidien = $row['anhdaidien'];
        $this->anhcreenshot = $row['anhcreenshot'];
        $this->id_danhmuc = $row['id_danhmuc'];
    }

    //create data
    public function create(){
        $query = "INSERT INTO phim_tbl SET tenphim=:tenphim, tentacgia=:tentacgia, IMDB=:IMDB, linkphim=:linkphim, mota=:mota, ngayramat=:ngayramat, thoiluong=:thoiluong, anhdaidien=:anhdaidien, anhcreenshot=:anhcreenshot,id_danhmuc=:id_danhmuc";
        $stmt = $this->conn->prepare($query);
        //clean data
        $this->tenphim = htmlspecialchars(strip_tags($this->tenphim));
        $this->tentacgia = htmlspecialchars(strip_tags($this->tentacgia));
        $this->IMDB = htmlspecialchars(strip_tags($this->IMDB));
        $this->linkphim = htmlspecialchars(strip_tags($this->linkphim));
        $this->mota = htmlspecialchars(strip_tags($this->mota));
        $this->ngayramat = htmlspecialchars(strip_tags($this->ngayramat));
        $this->thoiluong = htmlspecialchars(strip_tags($this->thoiluong));
        $this->anhdaidien = htmlspecialchars(strip_tags($this->anhdaidien));
        $this->anhcreenshot = htmlspecialchars(strip_tags($this->anhcreenshot));
        $this->id_danhmuc = htmlspecialchars(strip_tags($this->id_danhmuc));

        $stmt->bindParam(':tenphim',$this->tenphim);
        $stmt->bindParam(':tentacgia',$this->tentacgia);
        $stmt->bindParam(':IMDB',$this->IMDB);
        $stmt->bindParam(':linkphim',$this->linkphim);
        $stmt->bindParam(':mota',$this->mota);
        $stmt->bindParam(':ngayramat',$this->ngayramat);
        $stmt->bindParam(':thoiluong',$this->thoiluong);
        $stmt->bindParam(':anhdaidien',$this->anhdaidien);
        $stmt->bindParam(':anhcreenshot',$this->anhcreenshot);
        $stmt->bindParam(':id_danhmuc',$this->id_danhmuc);

        if($stmt->execute()){
            return true;
        }
        printf("Error %s.\n" ,$stmt->error);
            return false;
    }


    //update data
    public function update(){
        $query = "UPDATE phim_tbl SET tenphim=:tenphim, tentacgia=:tentacgia, IMDB=:IMDB, linkphim=:linkphim, mota=:mota, ngayramat=:ngayramat, thoiluong=:thoiluong, anhdaidien=:anhdaidien, anhcreenshot=:anhcreenshot,id_danhmuc=:id_danhmuc WHERE id_phim=:id_phim ";
        $stmt = $this->conn->prepare($query);
        //clean data
        $this->tenphim = htmlspecialchars(strip_tags($this->tenphim));
        $this->tentacgia = htmlspecialchars(strip_tags($this->tentacgia));
        $this->IMDB = htmlspecialchars(strip_tags($this->IMDB));
        $this->linkphim = htmlspecialchars(strip_tags($this->linkphim));
        $this->mota = htmlspecialchars(strip_tags($this->mota));
        $this->ngayramat = htmlspecialchars(strip_tags($this->ngayramat));
        $this->thoiluong = htmlspecialchars(strip_tags($this->thoiluong));
        $this->anhdaidien = htmlspecialchars(strip_tags($this->anhdaidien));
        $this->anhcreenshot = htmlspecialchars(strip_tags($this->anhcreenshot));
        $this->id_danhmuc = htmlspecialchars(strip_tags($this->id_danhmuc));
        $this->id_phim = htmlspecialchars(strip_tags($this->id_phim));

        //bind data
        $stmt->bindParam(':tenphim',$this->tenphim);
        $stmt->bindParam(':tentacgia',$this->tentacgia);
        $stmt->bindParam(':IMDB',$this->IMDB);
        $stmt->bindParam(':linkphim',$this->linkphim);
        $stmt->bindParam(':mota',$this->mota);
        $stmt->bindParam(':ngayramat',$this->ngayramat);
        $stmt->bindParam(':thoiluong',$this->thoiluong);
        $stmt->bindParam(':anhdaidien',$this->anhdaidien);
        $stmt->bindParam(':anhcreenshot',$this->anhcreenshot);
        $stmt->bindParam(':id_danhmuc',$this->id_danhmuc);
        $stmt->bindParam(':id_phim',$this->id_phim);
        
        if($stmt->execute()){
            return true;
        }
        printf("Error %s.\n" ,$stmt->error);
            return false;
    }


    //delete data
    public function delete(){
        $query = "DELETE FROM phim_tbl WHERE id_phim=:id_phim ";
        $stmt = $this->conn->prepare($query);
        //clean data

        $this->id_phim = htmlspecialchars(strip_tags($this->id_phim));

        //bind data

        $stmt->bindParam(':id_phim',$this->id_phim);
        
        if($stmt->execute()){
            return true;
        }
        printf("Error %s.\n" ,$stmt->error);
            return false;
    }


}
?>