<?php
    header('Access-Control-Allow-Origin:*');
    header('Content-Type: Application/json');
    header('Access-Control-Allow-Methods: PUT');
    header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');

    include_once('../../config/db.php');
    include_once('../../model/data.php');

    $db = new db();
    $connect = $db->connect();
    
    $data = new data($connect);

    $dulieu = json_decode(file_get_contents("php://input"));

    $data->id_phim = $dulieu->id_phim;
    $data->tenphim = $dulieu->tenphim;
    $data->tentacgia = $dulieu->tentacgia;
    $data->IMDB = $dulieu->IMDB;
    $data->linkphim = $dulieu->linkphim;
    $data->mota = $dulieu->mota;
    $data->ngayramat = $dulieu->ngayramat;
    $data->thoiluong = $dulieu->thoiluong;
    $data->anhdaidien = $dulieu->anhdaidien;
    $data->anhcreenshot = $dulieu->anhcreenshot;
    $data->id_danhmuc = $dulieu->id_danhmuc;

    if($data->update()){
        echo json_encode(array('message','Data Updated'));
    }else{
        echo json_encode(array('message','Data Not Updated'));
    }

?>