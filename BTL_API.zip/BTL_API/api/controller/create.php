<?php
    header('Access-Control-Allow-Origin:*');
    header('Content-Type: Application/json');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,X-Requested-With');

    include_once('../../config/db.php');
    include_once('../../model/data.php');

    $db = new db();
    $connect = $db->connect();
    
    $data = new data($connect);

    $dulieu = json_decode(file_get_contents("php://input"));
    $data->tenphim = $dulieu->tenphim;
    $data->tentacgia = $dulieu->tentacgia;
    $data->IMDB = $dulieu->IMDB;
    $data->linkphim = $dulieu->linkphim;
    $data->mota = $dulieu->mota;
    $data->ngayramat = $dulieu->ngayramat;
    $data->thoiluong = $dulieu->thoiluong;
    $data->anhdaidien = $dulieu->anhdaidien;
    $data->anhcreenshot = $dulieu->anhcreenshot;
    $data->id_danhmuc = $dulieu->id_danhmuc;

    if($data->create()){
        echo json_encode(array('message','Data Created'));
    }else{
        echo json_encode(array('message','Data Not Created'));
    }

?>