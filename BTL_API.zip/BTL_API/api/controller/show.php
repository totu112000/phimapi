<?php
    header('Access-Control-Allow-Origin:*');
    header('Content-Type: Application/json');

    include_once('../../config/db.php');
    include_once('../../model/data.php');

    $db = new db();
    $connect = $db->connect();
    
    $data = new data($connect);

    $data->id_phim = isset($_GET['id']) ? $_GET['id'] : die();

    $data->show();

    $data_item = array(
            'id_data' => $data->id_phim,
            'tenphim' => $data->tenphim,
            'tentacgia' => $data->tentacgia,
            'IMDB' => $data->IMDB,
            'linkphim' => $data->linkphim,
            'mota' => $data->mota,
            'ngayramat' => $data->ngayramat,
            'thoiluong' => $data->thoiluong,
            'anhdaidien' =>$data->anhdaidien,
            'anhcreenshot' => $data->anhcreenshot,
            'id_danhmuc' => $data->id_danhmuc
        );
    print_r(json_encode($data_item));
    

?>