<?php
    header('Access-Control-Allow-Origin:*');
    header('Content-Type: Application/json');

    include_once('../../config/db.php');
    include_once('../../model/data.php');

    $db = new db();
    $connect = $db->connect();
    
    $data = new data($connect);
    $read = $data->read();

    $num = $read->rowCount();
    if($num>0){
        $data_array = [];
        $data_array['dulieu'] = [];

        while($row = $read->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $data_item = array(
                'id_data' => $id_phim,
                'tenphim' => $tenphim,
                'tentacgia' => $tentacgia,
                'IMDB' => $IMDB,
                'linkphim' => $linkphim,
                'mota' => $mota,
                'ngayramat' => $ngayramat,
                'thoiluong' => $thoiluong,
                'anhdaidien' =>$anhdaidien,
                'anhcreenshot' => $anhcreenshot,
                'id_danhmuc' => $id_danhmuc
            );
            array_push($data_array['dulieu'],$data_item);
        }
        echo json_encode($data_array);
    }
?>